# CLI for the Kubestack GitOps Framework

`kbst` improves the GitOps developer experience by making a number of common tasks easier.

> The CLI never makes any changes to any cloud environment. All changes are exclusively to the local environment and working directory.
